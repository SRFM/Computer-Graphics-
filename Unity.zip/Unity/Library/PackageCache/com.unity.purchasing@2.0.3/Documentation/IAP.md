# Unity In-App Purchasing (IAP)

Unity IAP makes it easy to implement in-app purchases in your application across the most popular App stores.

Supported platforms include:

* iOS App Store
* Mac App Store
* Google Play
* Universal Windows Platform
* Amazon Appstore
* Samsung Galaxy Apps
* Tizen Store
* CloudMoolah Store
* Facebook Gameroom
* Xiaomi Mi Game Pay