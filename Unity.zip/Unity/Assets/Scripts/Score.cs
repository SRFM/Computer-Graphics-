﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public Text scoreText;
    private float time = 0;
    

    void Start()
    {
        scoreText = this.GetComponent<Text>();
        

    }


    void Update()
    {
        time += Time.deltaTime;
        scoreText.text = ("Score is:" + GetScore().ToString());
        scoreText.text += ("\n Available hammers are:" + StartWorld.k);
        scoreText.text += ("\n Teleport from another cube is enabled:" + Teleport.isEnabled);
        if (Hammer.isFinished)
        {
            scoreText.text = ("Score is: 0");
        }
    }
    private float GetScore()
    {
        float score = (StartWorld.n ^ 2) - (time) - Hammer.hammerUsed * 50;
        return score;
    }
    
}

