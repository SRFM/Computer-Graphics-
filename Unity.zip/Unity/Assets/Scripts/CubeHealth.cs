﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;


public class CubeHealth : MonoBehaviour
{
    public GameObject hammerSpawn;
    public int health = 30;
    [SerializeField] GameObject BlueFragment;
    [SerializeField] GameObject HammerSpawn;
    private GameObject go;
    private FirstPersonController audio;
    

    private void Start()
    {

        hammerSpawn = Instantiate(HammerSpawn, transform.position, Quaternion.identity);
        hammerSpawn.SetActive(false);
        audio = GameObject.FindWithTag("Player").GetComponent<FirstPersonController>();


    }
    void Update()
    {
        if (health <= 0)
        {
            go = Instantiate(BlueFragment, transform.position, Quaternion.identity);
            audio.PlayDestructionSound();
            DropChance();
            gameObject.SetActive(false);

        }
        return;
    }

    private void DropChance()
    {
        float chance = Mathf.RoundToInt(Random.Range(0, 2));
        if (chance == 1)
        {
            hammerSpawn.SetActive(true);
        }
    }

    private void OnDisable()
    {
        Destroy(go, 1.5f);
    }
}      

        
    


