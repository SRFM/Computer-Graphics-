﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class Teleport : MonoBehaviour
{
    public static bool isEnabled = true;
    private Light teleportLight;
    private GameObject TeleportParent;
    private CharacterController player;
    private BoxCollider boxCollider;
    private FirstPersonController audio;
   


    private void Start()
    {
        TeleportParent = GameObject.FindWithTag("Respawn").GetComponent<StartWorld>().TeleportParent;
        player = GameObject.FindWithTag("Player").GetComponent<CharacterController>();
        teleportLight = GameObject.FindWithTag("Player").transform.Find("Teleport Light").GetComponent<Light>();
        audio = GameObject.FindWithTag("Player").GetComponent<FirstPersonController>();



    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            
            if (player.transform.position.y >= -1 && player.transform.position.y < 0)
            {
                player.transform.position = GetWaypoint(1);
                StartCoroutine(waitForTeleportSec(5f, 1));
                StartCoroutine(waitForLightSec(1f));
                
            }
            else if (player.transform.position.y > 0 && player.transform.position.y < 1)
            {
                
                player.transform.position = GetWaypoint(2);
                StartCoroutine(waitForTeleportSec(5f, 2));
                StartCoroutine(waitForLightSec(1f));
                

            }
            else if (player.transform.position.y > 1 && player.transform.position.y < 2)
            {
                player.transform.position = GetWaypoint(3);
                StartCoroutine(waitForTeleportSec(5f, 3));
                StartCoroutine(waitForLightSec(1f));
                


            }
            
            else
            {
                player.transform.position = GetWaypoint(0);
                StartCoroutine(waitForTeleportSec(5f, 0));
                StartCoroutine(waitForLightSec(1f));
                


            }


        }
    }
    private Vector3 GetWaypoint(int i)
    {
        return TeleportParent.transform.GetChild(i).position;
    }

    private BoxCollider GetBoxpoint(int i)
    {
        return TeleportParent.transform.GetChild(i).GetComponent<BoxCollider>();
    }

    private IEnumerator waitForTeleportSec(float sec, int i)
    {
        GetBoxpoint(i).enabled = false;
        isEnabled = false;
        yield return new WaitForSeconds(sec);
        GetBoxpoint(i).enabled = true;
        isEnabled = true;

    }
    private IEnumerator waitForLightSec(float sec)
    {
  
        teleportLight.enabled = true;
        audio.PlayTeleportSound();
        yield return new WaitForSeconds(sec);
        teleportLight.enabled = false;
    }
}
