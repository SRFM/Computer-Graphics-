﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.Characters.FirstPerson;


public class Hammer : MonoBehaviour
{
    public static int hammerUsed = 0;
    public  static bool isFinished = false;
    [SerializeField] int damage = 10;
    [SerializeField] int hammerHealth = 100;
    [SerializeField] AudioClip clip;
    private Animator animator;
    private RaycastHit hit;
    private Renderer renderer;
    private Material materialHammer;
    private FirstPersonController audio;
    
    
    


    // Start is called before the first frame update
    void Start()
    {
        animator = this.GetComponent<Animator>();
        renderer = this.GetComponent<Renderer>();
        audio = GameObject.FindWithTag("Player").GetComponent<FirstPersonController>();
        
        

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            animator.Play("Hit");
            BoxDetect();
            
        }
        if (Input.GetKeyDown(KeyCode.X))
        {
            isFinished = true;
            GameObject.FindGameObjectWithTag("Finish").GetComponent<GameWinner>().GameEnd();
            

        }
    }
    void BoxDetect()
    {
        
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray, out hit, 0.9f))
        {
            if (hit.transform.gameObject.tag == "Cube")
            {

                Debug.Log("this is " + hit.transform.name);
                hit.transform.gameObject.GetComponent<CubeHealth>().health -= damage;
                ChangeHammer();
                audio.PlayHitSound();
                

            }
            return;

        }
    }
    void ChangeHammer()
    {
        
        
        if (hammerHealth <= 100 && hammerHealth>=80)
        {
            hammerHealth -= 10;
            
           
        }
        else if (hammerHealth <=70 && hammerHealth>=40)
        {
            hammerHealth -= 10;
            materialHammer = Resources.Load("HammerRed", typeof(Material)) as Material;
            renderer.material = materialHammer;
        }

        else if (hammerHealth <=30 && hammerHealth>0 )
        {
            hammerHealth -= 10;
            materialHammer = Resources.Load("HammerBlack", typeof(Material)) as Material;
            renderer.material = materialHammer;


        }
        else
        {
            hammerHealth = 100;
            StartWorld.k -= 1;
            if (StartWorld.k == 0)
            {
                GameObject.FindGameObjectWithTag("Finish").GetComponent<GameWinner>().GameEnd();
            }
            hammerUsed++;
            Debug.Log(StartWorld.k);
            hammerHealth -= 10;
            materialHammer = Resources.Load("HammerSimple", typeof(Material)) as Material;
            renderer.material = materialHammer;
        }
       

        Debug.Log("hammer is at " + hammerHealth);
        return;
    }
    
}
