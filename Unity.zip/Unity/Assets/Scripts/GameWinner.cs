﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class GameWinner : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Player is in");
            if (Input.GetKeyDown(KeyCode.E))
            {
                GameEnd();
            }
        }
        return;
    }

    public void GameEnd()
    {
        Time.timeScale = 0;
        GameObject.FindWithTag("Player").GetComponent<FirstPersonController>().enabled = false;
    }
}
