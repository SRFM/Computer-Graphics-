﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;
using Random = UnityEngine.Random;

public class StartWorld : MonoBehaviour
{
    public static int k;
    public static int n;
    public static int l;
    public GameObject TeleportParent;



    [SerializeField] GameObject RED;
    [SerializeField] GameObject GREEN;
    [SerializeField] GameObject BLUE;
    [SerializeField] GameObject T1;
    [SerializeField] GameObject T2;
    [SerializeField] GameObject T3;
    [SerializeField] GameObject Empty;
    [SerializeField] GameObject Teleport;
    [SerializeField] GameObject frontBoundary;
    [SerializeField] GameObject leftBoundary;
    [SerializeField] GameObject rightBoundary;
    [SerializeField] GameObject backBoundary;
    [SerializeField] GameObject winBoundary;
    [SerializeField] GameObject floorBoundary;
    [SerializeField] GameObject player;
    [SerializeField] GameObject mazeLight;
    [SerializeField] Canvas scoreCanvas;
    [SerializeField] List<Vector3> pos = new List<Vector3>();



    private float y=-1;
    private string str;
    private float z;
    private float x;
    private GameObject redParent;
    private GameObject blueParent;
    private GameObject greenParent;
    private GameObject T1Parent;
    private GameObject T2Parent;
    private GameObject T3Parent;
    private GameObject EmptyParent;
    private GameObject Boundaries;






    void Awake()
    {
        InitParents();
        InitBoundaries();
        InitFromFIle();
        // Instantiate(player, new Vector3(1, 6, 15), Quaternion.identity);
        Instantiate(mazeLight, new Vector3(6, 10, 6), Quaternion.Euler(90,0,0));
        Instantiate(scoreCanvas, new Vector3(0, 0, 0), Quaternion.identity);
        InitRandomPosition();


    }

    private void InitRandomPosition()
    {
        int capacity = EmptyParent.transform.childCount;
        int count = 0;
        for (int i = 0; i < capacity; i++)
        {

            if (EmptyParent.transform.GetChild(i).position.y != 0)
            {
                continue;
            }
            pos.Add(EmptyParent.transform.GetChild(i).position);
            count++;





        }

        int randomPos = Mathf.RoundToInt(Random.Range(0, count));
        Instantiate(player, pos[randomPos], Quaternion.identity);
    }

    public void InitParents()
    {
        redParent = new GameObject("REDPARENT");
        greenParent = new GameObject("GREENPARENT");
        blueParent = new GameObject("BLUEPARENT");
        T1Parent = new GameObject("T1PARENT");
        T2Parent = new GameObject("T2PARENT");
        T3Parent = new GameObject("T3PARENT");
        EmptyParent = new GameObject("EMPTYPARENT");
        Boundaries = new GameObject("BOYNDARIES");
        TeleportParent = new GameObject("TELEPORTTPARENT");
        redParent.transform.parent = this.gameObject.transform;
        greenParent.transform.parent = this.gameObject.transform;
        blueParent.transform.parent = this.gameObject.transform;
        T1Parent.transform.parent = this.gameObject.transform;
        T2Parent.transform.parent = this.gameObject.transform;
        T3Parent.transform.parent = this.gameObject.transform;
        EmptyParent.transform.parent = this.gameObject.transform;
        Boundaries.transform.parent = this.gameObject.transform;
        TeleportParent.transform.parent = this.gameObject.transform;

    }

    private void InitBoundaries()
    {
        GameObject floor = Instantiate(floorBoundary, new Vector3(8, -1, 7.5f), Quaternion.Euler(90, 0, 0));
        GameObject win = Instantiate(winBoundary, new Vector3(7.5f, 4, 7.5f), Quaternion.Euler(90, 0, 0));
        GameObject front = Instantiate(frontBoundary, new Vector3(7.5f, 1, -1), Quaternion.identity);
        GameObject right = Instantiate(rightBoundary, new Vector3(16, 1, 7.5f), Quaternion.Euler(new Vector3(0, -90, 0)));
        GameObject back = Instantiate(backBoundary, new Vector3(7.5f, 1, 16), Quaternion.identity);
        GameObject left = Instantiate(leftBoundary, new Vector3(-1, 1, 7.5f), Quaternion.Euler(new Vector3(0, 90, 0)));
        floor.transform.parent = Boundaries.transform;
        win.transform.parent = Boundaries.transform;
        front.transform.parent = Boundaries.transform;
        right.transform.parent = Boundaries.transform;
        back.transform.parent = Boundaries.transform;
        left.transform.parent = Boundaries.transform;
    }

    private void InitFromFIle()
    {
        int i = 0;
        int b = 0;
        //BLACKBOXES = new Vector3[size];
        StreamReader maze = new StreamReader("Assets/MazeRead/file.maz");
        string stringWithMultipleSpaces = maze.ReadToEnd();
        maze.Close();
        Regex a = new Regex("\n");
        string[] words = a.Split(stringWithMultipleSpaces);
        string buffer;
        do
        {
            buffer = words[i];
            if (buffer[0].Equals('L') && buffer[1].Equals('='))
            {
                for (int j = 2; j < buffer.Length; j++)
                {
                    str += buffer[j];
                }

                try
                {

                    l = Int32.Parse(str);

                }
                catch (FormatException e)
                {
                    print(e.Message);

                }
                str = "";
            }
            else if (buffer[0].Equals('N') && buffer[1].Equals('='))
            {
                for (int j = 2; j < buffer.Length; j++)
                {
                    str += buffer[j];
                }
                try
                {
                    n = Int32.Parse(str);
                }
                catch (FormatException e)
                {
                    print(e.Message);

                }
                str = "";
            }
            else if (buffer[0].Equals('K') && buffer[1].Equals('='))
            {
                for (int j = 2; j < buffer.Length; j++)
                {
                    str += buffer[j];
                }
                try
                {
                    k = Int32.Parse(str);
                }
                catch (FormatException e)
                {
                    print(e.Message);

                }
                str = "";
            }
            else if (buffer[0].Equals('L') && buffer[1].Equals('E'))
            {
                y++;
                z = 0;
            }
            else if (y >= 0 && y < n)
            {
                x = 0;
                for (int j = 0; j < buffer.Length; j++)
                {
                    if (buffer[j] == 'R')
                    {
                        //red cube

                        GameObject red=Instantiate(RED, new Vector3(x, y, z), Quaternion.identity);
                        red.transform.parent = redParent.transform;
                        x++;
                    }
                    else if (buffer[j] == 'B')
                    {
                        //blue cube
                        GameObject blue=Instantiate(BLUE, new Vector3(x, y, z), Quaternion.identity);
                        blue.transform.parent = blueParent.transform;
                        x++;
                    }
                    else if (buffer[j] == 'G')
                    {
                        //green cube
                        GameObject green=Instantiate(GREEN, new Vector3(x, y, z), Quaternion.identity);
                        green.transform.parent = greenParent.transform;

                        x++;
                    }
                    else if (buffer[j] == 'T')
                    {
                        j++;
                        if (j < buffer.Length && buffer[j] == '1')
                        {
                            //T1cube
                            GameObject T1Child=Instantiate(T1, new Vector3(x, y, z), Quaternion.identity);
                            T1Child.transform.parent = T1Parent.transform;
                            x++;
                        }
                        if (j < buffer.Length && buffer[j] == '2')
                        {
                            //T2cube
                            GameObject T2Child=Instantiate(T2, new Vector3(x, y, z), Quaternion.identity);
                            T2Child.transform.parent = T2Parent.transform;
                            x++;
                        }
                        if (j < buffer.Length && buffer[j] == '3')
                        {
                            //T3cube
                            GameObject T3Child=Instantiate(T3, new Vector3(x, y, z), Quaternion.identity);
                            T3Child.transform.parent = T3Parent.transform;
                            x++;
                        }
                    }
                    else if (j < buffer.Length && buffer[j] == 'W')
                    {
                        //Teleport
                        GameObject TeleportChild=Instantiate(Teleport, new Vector3(x, y, z), Quaternion.identity);
                        TeleportChild.transform.parent = TeleportParent.transform;
                        //BLACKBOXES[b] = new Vector3(x, y, z);
                        //print(BLACKBOXES[b]);
                        b++;
                        x++;
                    }
                    else if (buffer[j] == 'E')
                    {
                        if (buffer[j + 1] != 'N')
                        {
                            GameObject emptyChild=Instantiate(Empty, new Vector3(x, y, z), Quaternion.identity);
                            emptyChild.transform.parent = EmptyParent.transform;
                        }
                        x++;
                    }
                }
                z++;

            }
            i++;


        } while (i < words.Length - 1);
    }


}
